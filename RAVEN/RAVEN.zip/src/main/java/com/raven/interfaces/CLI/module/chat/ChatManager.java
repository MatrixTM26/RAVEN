package com.raven.interfaces.CLI.module.chat;

import com.raven.utils.TerminalHelper;
import com.raven.core.database.TeamDatabase;
import com.raven.core.output.Logger;
import com.raven.utils.AnsiColor;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public final class ChatManager {

    private static final DateTimeFormatter TimeFormat  = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final int               MaxMessages = 500;

    private final List<Map<String, Object>> MessageHistory = new CopyOnWriteArrayList<>();
    private final TeamDatabase              Database;

    private String OperatorName;

    public ChatManager(TeamDatabase Database) {
        this.Database = Database;
    }

    public void SetOperator(String OperatorName) {
        this.OperatorName = OperatorName;
    }

    public void Send(String Recipient, String Message) {
        if (OperatorName == null) { Logger.Info("not in team mode"); return; }
        Map<String, Object> Entry = new LinkedHashMap<>();
        Entry.put("From",    OperatorName);
        Entry.put("To",      Recipient);
        Entry.put("Message", Message);
        Entry.put("Time",    LocalTime.now().format(TimeFormat));
        MessageHistory.add(Entry);
        if (MessageHistory.size() > MaxMessages) MessageHistory.remove(0);
        Database.SaveChatLog(OperatorName, Recipient, Message);
        Logger.Custom("  Message sent to [%s%s%s]%n", AnsiColor.Green, Recipient, AnsiColor.Reset);
    }

    public void ShowLocalMessages() {
        System.out.println(TerminalHelper.Box("CHAT MESSAGES"));
        System.out.println();
        if (MessageHistory.isEmpty()) { Logger.Info("no messages\n"); return; }
        String CurrentOperator = OperatorName != null ? OperatorName : "";
        for (Map<String, Object> Message : MessageHistory) {
            String  From      = Message.getOrDefault("From", "?").toString();
            String  To        = Message.getOrDefault("To", "all").toString();
            String  Content   = Message.getOrDefault("Message", "").toString();
            String  Timestamp = Message.getOrDefault("Time", "").toString();
            boolean IsMine    = From.equals(CurrentOperator);
            String  ToLabel   = To.equals("all") ? "all" : "> " + To;
            Logger.Custom("  %s[%s] %s%s%s [%s]: %s%s%n",
                IsMine ? AnsiColor.Green : AnsiColor.White,
                Timestamp,
                IsMine ? AnsiColor.Green : AnsiColor.Red,
                From, AnsiColor.Reset,
                ToLabel, Content, AnsiColor.Reset);
        }
        System.out.println();
    }

    public void ShowDatabaseHistory() {
        List<Map<String, Object>> Records = Database.GetChatLogs(100);
        System.out.println(TerminalHelper.Box("CHAT HISTORY (Database - last 100)"));
        System.out.println();
        if (Records.isEmpty()) { Logger.Info("no chat history in database\n"); return; }
        String CurrentOperator = OperatorName != null ? OperatorName : "";
        for (Map<String, Object> Record : Records) {
            String  From      = Record.getOrDefault("From", "?").toString();
            String  To        = Record.getOrDefault("To", "all").toString();
            String  Content   = Record.getOrDefault("Message", "").toString();
            String  Timestamp = Record.getOrDefault("Timestamp", "").toString();
            if (Timestamp.length() > 11) Timestamp = Timestamp.substring(11, Math.min(19, Timestamp.length()));
            boolean IsMine  = From.equals(CurrentOperator);
            String  ToLabel = "all".equals(To) ? "all" : "> " + To;
            Logger.Custom("  %s[%s] %s%s%s [%s]: %s%s%n",
                IsMine ? AnsiColor.Green : AnsiColor.White,
                Timestamp,
                IsMine ? AnsiColor.Green : AnsiColor.Red,
                From, AnsiColor.Reset,
                ToLabel, Content, AnsiColor.Reset);
        }
        System.out.println();
    }
}
